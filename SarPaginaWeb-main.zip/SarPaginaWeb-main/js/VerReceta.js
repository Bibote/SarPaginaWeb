function verReceta(id) {
    location.href="Receta.php?id="+id;

}