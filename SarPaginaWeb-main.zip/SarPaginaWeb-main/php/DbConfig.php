<?php
$local=0; //0 para la nube
if ($local==1){
    $server="localhost";
    $user="root";
    $pass="";
    $basededatos="sar";
}
else{
    $server="localhost:3306";
    $user="root";
    $pass="";
    $basededatos="sar";
}
?>
