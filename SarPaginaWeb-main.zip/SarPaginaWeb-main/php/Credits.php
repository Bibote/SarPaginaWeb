<!DOCTYPE html>
<html>
<head>
  <?php include '../html/Head.html'?>
</head>
<body>
  <?php include '../php/Menus.php' ?>
  <section class="main" id="s1">
    <div>

      <h2>DATOS DEL AUTOR/AUTORES</h2>

    </div>
  </section>
</body>
</html>
