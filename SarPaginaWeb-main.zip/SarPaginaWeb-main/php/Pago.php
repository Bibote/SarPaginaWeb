<!DOCTYPE html>
<html>
<head>
  <?php include '../html/Head.html'?>
</head>
<body>
  <?php include '../php/Menus.php' ?>
  <section class="main" id="s1">
    <div>

      <h2>Pagos</h2>

    </div>
    <input type="button" id="verPreguntas" value="verPreguntas" onclick="verLocalizacion()">
    <div id='verTabla'>
  </section>
  <script src="../js/ViewQuestionsAjax.js"></script>
</body>
</html>
