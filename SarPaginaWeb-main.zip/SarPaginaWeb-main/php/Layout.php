<!DOCTYPE html>
<html>
<head>
  <?php include '../html/Head.html'?>
  <style type="text/css">
			body{
				background-image: url(../images/fondoregistro.png);
        text-align:center;
				
				}
  </style>
</head>
<body>
  <?php include '../php/Menus.php' ?>
  <section class="main" id="s1">
    <div>
    <h2>Recetalandia</h2>
      
      
    </div>
  </section>
</body>
</html>
